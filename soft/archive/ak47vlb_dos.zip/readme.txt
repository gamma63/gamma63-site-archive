CSC AK47 Controller Card Dos/Windows 31 drivers.
------------------------------------------------

Driver Installation:
--------------------

For both MSDos and Windows 31 first copy the dos driver into a directory
on your hard drive. Then, edit the "CONFIG.SYS" file by typing 
"edit config.sys" at the dos C:\ prompt.

Add the following line to the top of the "CONFIG.SYS" file:

	DEVICE=C:\SCSI\AK47ASPI.SYS 

Where "C:\SCSI" is the directory where the drivers are now located.


Command line options:
---------------------

The following options can be added to the DEVICE line in your "CONFIG.SYS":

/SASI           -- use SASI type SCSI commands
/RESETWAIT      -- wait longer after SCSI reset for slow drives
/NOPARITY       -- disable SCSI bus parity checking
/PORT:xxxx      -- SCSI chip port override
/IRQ:nn         -- SCSI chip IRQ override

For example:
	DEVICE=C:\SCSI\AK47ASPI.SYS /PORT:320 /IRQ:15

------------------------
Corporate Systems Center
1294 Hammerwood Ave
Sunnyvale CA 94089
408-734-3475