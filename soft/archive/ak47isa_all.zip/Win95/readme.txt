CSC AK-47 Windows 95 Scsi Miniport Driver.
------------------------------------------

Driver Installation:
--------------------

If you are installing Windows 95 for the first time, just install normally 
then follow the instructions below.

Note: Make sure you know what settings your CSC FastCache controller is at 
(i.e. Memory Address, I/O Address, & IRQ). Please consult your manual and 
check your settings because the driver will not load properly without these 
settings.

From the START MENU, choose Settings and then click on 'Control Panel'
When the Control Panel appears click on the icon: 'Add New Hardware'

The Add New Hardware Wizard window will appear. Now click the 'Next>' button.
Windows 95 will now ask if you want Windows to search for new hardware. Click 
on 'No' and then click the 'Next>' button.

The next window is for hardware type selection. Scroll down to 'SCSI 
controllers', click on it and the click the 'Next>' button.

On the next window there is a 'Have Disk..' button. Click on it and insert 
your CSC Windows NT & 95 Diskette into your floppy drive. The Install From 
Disk window will appear.  Select the correct drive to copy the driver files 
from and click 'OK'.

Next, a window listing the CSC controllers will appear.  Choose the correct 
driver for your controller and click on the 'Next>' button.

The following window will contain some hardware settings that probably wont 
match your controller, but don't worry about that now just click on the 
'Next>' button.

Windows will now ask if you want to restart your system. Click on 'No' and 
go back to the Control Panel. Click on the icon: 'System' to bring up the 
system properties. From inside the window, click on the Device Manager tab.
The CSC driver you just loaded should appear in the window, click on it and 
then the 'Properties' button. From inside this window, click on the 
Resources tab. The resource settings in the window need to match the 
settings that are on the controller including Memory Range, Input/Output 
Range, & Interrupt Request.  To change these settings, click on the resource 
type (i.e. Memory Range) and then click on the 'Change Setting...' button.

Once all the settings are correct the system now needs to be shut down and 
rebooted.

After the system has been rebooted, the driver should load properly and it 
will automatically un-install the old ASPI manager.  To check if the driver 
is loaded, load the System from the Control Panel and check the performance.  
It should be 32-bit on the File System line.



Driver Options:
---------------

Under Windows95 These parameters can be entered directly into the registry
or via the driver properties page.

Registry location:

	\HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\
	CscAk47\Parameters\Device

InitiatorTargetId REG_DWORD (0..7)
DriverParameter REG_PSZ

DriverParameter is a string of options separated by spaces.  The following 
values can be set:

maxtransfer=nnnnnnnn	; Maximum transfer size.  
			Lower values make the mouse more responsive.  
			The default is 0x10000. Making this value smaller 
			than 4096 will cause 95 to run VERY slow.
	reasonable values:
		AK47 ISA 		0x8000
		AK47 VLB		0x8000-0x10000

disconnect	;enables disconnect

irq=nn		;override for irq number.  Required if bios is disabled.


------------------------
Corporate Systems Center
1294 Hammerwood Ave
Sunnyvale CA 94089
408-734-3475