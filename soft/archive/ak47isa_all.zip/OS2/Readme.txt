CSC FASTCACHE AK-47 OS/2 DRIVER VERSION 1.21
May 4, 1995    README FILE


INSTALLATION INSTRUCTIONS
*************************
1. Installing OS/2 from CD-ROM

To install OS/2 to a supported boot drive via CD-ROM attached
to the AK47, first use diskcopy A: A: to make a backup copy 
of the OS/2 CD-ROM "Install Disk 1" and the OS/2 "Diskette
for CD-ROM".

Next, using the copy command, copy the file "CSCAK47.ADD" from
the AK-47 Diskette to the backup install disk.  Edit the 
"CONFIG.SYS" file on this disk, and add the following line to
the end of the CONFIG.SYS:

       BASEDEV=CSCAK47.ADD


Reboot the system with the OS/2 CD-ROM "Install Disk 1" in 
your boot drive.  When OS/2 asks for "Diskette for CD-ROM"
insert your new disk. The installation process will be 
completed automatically.



2. Installing OS/2 FROM FLOPPIES

Proceed with normal OS/2 installation from floppies as
described in the IBM manuals.  This procedure will complete
using the built-in OS/2 "Int-13" driver.

When the installation screen "Advanced Options" appears, 
select the check box for prompt for "Install device support diskette".
insert the AK-47 Diskett and select OK.  This will automatically
update the OS/2 installation to load the CSCAK47 device driver.



3.  Installing the device driver to an existing OS/2 system

Select the Device Driver Install Icon in the System Setup Folder.  
The OS/2 device driver installation program will load.  Place 
the AK-47 Diskette in the floppy drive. Select the Install button 
to update the existing system.



DEVICE DRIVER OPTIONS
*********************
The CSCAK47.ADD driver supports all standard OS/2 ADD SCSI
command line parameters.  A description of these 
parameters is listed below.  You may view the OS/2
help file for SCSI command line parameters by clicking on the
information Icon, and selecting the command reference.  Open the
topic "OS/2 commands by name", and look up the BASEDEV command.
select Adapter Device Driver parameters for more information on how
to use these parameters as specified for CSCAK47.ADD. 

The following BASEDEV parameters are supported, with
defaults shown in parentheses:

Verbose Mode:           (/V)    /!V 
Debug Mode:             /DEBUG /DEBUG:nnnn 
Adapter No:             /A:n 
Host ID:                /ID:nn    (7)
Port No:                /PORT:nnnn (auto)
IRQ No:                 /IRQ:nn   (auto)
Ignore Adapter:         /IGNORE
Target No:              /T:n 
Disconnect Mode:        /D /D:n (/!D) /!D:n 
Synchronous Mode:       /SN /SN:n (/!SN) /!SN:n 
SCSI-2 Mode:            (/SCSI2) /SCSI2:n /!SCSI2 /!SCSI2:n 
DASD Manager:           (/DM) /DM:n /!DM /!DM:n
SCSI Manager:           (/SM) /SM:n /!SM /!SM:n
SCSI Parity:            /PARITY /!PARITY (auto detect)

The following options can be specified globally prior to an /A: option:

	/D /!D /SN /!SN /DM /!DM /SM /!SM /SCSI2 /!SCSI2 /PARITY /!PARITY


ABSTRACT
********
This is release 1.21 of the OS/2 2.x device driver for the 
CSC FastCache AK-47 SCSI-II controller.  This driver 
supports all tested SCSI devices, and is bootable.   The 
driver may be loaded from CD-ROM or floppy disk.
This driver supports the Warp Resource Manager.


IBM DISCLAIMER
**************
THIS DEVICE DRIVER AND ITS ACCOMPANYING DOCUMENTATION HAVE
BEEN LICENSED TO IBM BY CSC SOLELY FOR THE PURPOSE OF 
DISTRIBUTION.  MAINTENANCE AND SUPPORT OF THE DEVICE DRIVER 
IS THE RESPONSIBILITY OF CSC.  IBM MAKES NO WARRANTY,
EXPRESSED OR IMPLIED WITH RESPECT TO THE DEVICE DRIVER
INCLUDING WITHOUT LIMITATION, WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT WILL IBM
BE LIABLE FOR ANY DAMAGES (DIRECT OR INDIRECT) RESULTING
FROM A FAILURE OF THIS DEVICE DRIVER OR ITS ACCOMPANYING
DOCUMENTATION TO PERFORM TO THE USERS EXPECTATIONS.  IBM
GRANTS NO LICENSE TO PATENTS OR COPYRIGHTS WITH THIS DEVICE
DRIVER.  CONSULT THE ACCOMPANYING END USER DOCUMENTATION FOR
YOUR RIGHTS AND LICENSES.


FUNCTIONAL DESCRIPTION
**********************
Release 1.x of the OS/2 2.x device driver for the CSC AK47A 
Fast Vesa VL-Bus SCSI-II controller is a fast, multi 
threaded, interrupt driven driver.  This driver supports
CD-ROM, tape, and hard disk drives.   Other devices 
supported under OS/2 and under DOS windows in OS/2 through
VASPI may be used with this driver.  The driver is most
easily loaded during a CD-ROM installation, but may also be
loaded from floppy disk as described below.  This driver
provides about a 200% speed increase over the Int-13
device driver in most applications.


RESTRICTIONS
************
This release requires an FastCache AK-47 Rom BIOS revision of 1.14
or higher to boot OS/2 correctly.

The command line switch /D (for disconnect mode) will not
operate with all SCSI devices.  This option should normally
be left disabled unless several devices are connected to
the SCSI bus and all connected devices fully support 
SCSI-II disconnect features.

CSC LICENSE AGREEMENT
*********************
THE ACCOMPANYING SOFTWARE DEVICE DRIVERS ARE LICENSED TO
THE END USER FOR USE ONLY IN CONJUNCTION WITH CSC DISK 
CONTROLLERS.  THESE DEVICE DRIVERS ARE PROVIDED WITHOUT
WARRANTY, EXPRESSED OR IMPLIED WITH RESPECT TO THE DEVICE 
DRIVER PERFORMANCE, INCLUDING WITHOUT LIMITATION, WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  IN
NO EVENT WILL CSC BE LIABLE FOR ANY DAMAGES (DIRECT OR INDIRECT) 
RESULTING FROM A FAILURE OF THIS DEVICE DRIVER OR
ACCOMPANYING DOCUMENTATION TO PERFORM TO THE USERS 
EXPECTATIONS. CSC GRANTS NO LICENSE TO PATENTS OR COPYRIGHTS
WITH THIS DEVICE DRIVER. THIS DRIVER MAY CONTAINS 
COPYRIGHTED CODES AUTHORED BY �MAGIC, INC. AND DISTRIBUTED
BY CORPORATE SYSTEMS CENTER.


TRADEMARK ATTRIBUTIONS
**********************
OS/2 is a trademark of International Business Machines.
CSC FastCache AK-47 is a trademark of Computer Performance, Inc.
This driver is copyrighted by �-Magic (c) 1994,1995 and by
Corporate Systems Center (c) 1994.  This driver was
developed by �-Magic, Discovery Bay CA.


------------------------
Corporate Systems Center
1294 Hammerwood Ave
Sunnyvale CA 94089
408-734-3475