Novell Netware v4.0x Installation on the AK-47 Controller

(Note: with ANY SCSI controller, the automatic installation of Novell 4.0x with CD-ROM and target hard drive on the same Host adapter may hang before you finish the installation.  This is caused by an interrupt conflict between the DOS ASPI manager and the Novell driver.  If this occurs, follow the manual install procedure below.)
 
Try the following automatic procedure first.  If the system locks up please read the README.ALT file.

1.      Create a small DOS Partition on the Hard Drive
2.      Install the supplied AK-47 ASPI Driver
3.      Install an ASPI compatible CD-ROM Driver
4.      Reboot System
5.      Load MS-DOS CD-ROM extensions (MSCDEX)
6.      Change to CD-ROM drive letter
7.      Type "CD\NETWARE.<Version #>\ENGLISH" <Enter>
8.      Type "INSTALL" <Enter>
9.      Select "INSTALL NEW NETWARE V4.0X"
10.     Follow all On-Screen Prompts
11.     When you get to the "Load Disk Driver" Screen,
		Press "<INS>" to load alternate driver
		Insert the AK-47 Diskette w/the NOVELL Drivers
		Press "<F3>" to specify the directory
		Type "A:\NOVELL.40X" to specify the correct directory
12.     Choose AK474x.DSK Driver to load
13.     Continue to Follow all On-Screen Prompts
14.     NetWare installation is completed
