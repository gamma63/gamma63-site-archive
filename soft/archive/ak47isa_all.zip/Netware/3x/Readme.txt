Novell Netware v3.12 Installation on the AK-47 Controller

1.	Create a small DOS Partition on the Hard Drive
2.	Install the supplied AK-47 ASPI Driver
3.	Install an ASPI compatible CD-ROM Driver
4.	Reboot System
5.	Load MS-DOS CD-ROM extensions (MSCDEX)
6.	Change to CD-ROM drive letter
7.	Type "CD\NETWARE.312\ENGLISH" <Enter>
8.	Type "INSTALL" <Enter>
9.	Select "INSTALL NEW NETWARE V3.12"
10.	Follow all On-Screen Prompts
11.	When finished Down server
12.	Copy "AK473X.DSK" & "AK473X.DDI"  to C:\SERVER.312
13.	Boot "SERVER"
14.	Type "Load C:\SERVER.312\AK473X.DSK"
15.	Type "Load C:\SERVER.312\INSTALL"
16.	Select "Disk Options"
17.	Select "Partition Table"
18.	Select "Create NOVELL Partition"
19.	Go to Main Menu
20.	Select "Volume Options"
21.	Add Volume SYS
22.	Mount Volume SYS
23.	Go to Main Menu
24.	Select "System Options"
25.	Select "COPY SYSTEM and PUBLIC FILES"
26.	Press "<F6>" (for CD-ROM)
27.	Type "D:\NETWARE.312\ENGLISH"
28.	Wait for files to copy to hard drive
29.	Create AUTOEXEC.NCF
30.	Create STARUP.NCF
31.	Completed installation


CD-ROM Mount as a Volume
========================

1.	Load C:\SERVER.312\ASPICD
2.	Load C:\SERVER.312\CDROM.NLM
3.	Type "CD DEVICE LIST"
4.	Type "CD MOUNT (device number) (volume name)"

