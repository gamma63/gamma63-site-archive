===========================================================================
CORPORATE SYSTEMS CENTER         README.64S                October 02, 1992
===========================================================================

    Thank you for purchasing the CSC FastCache64 SCSI Controller.
    Included in this document you will a summary of the files inclided
    on this disk.

    This file may be printed by using the DOS command: 

TYPE ReadMe.64S > PRN

Note: Page formatting commands are embedded.



    FCSETUP.EXE - 10/02/92
        This in the setup program for the FC64.  It should be used during
        initial installation and after hardware changes are made to the
        SCSI or floppy drive system.

        See your CSC FastCache64 SCSI or CSC FlashCache64 SCSI manual for
        more information.

	FCCACHE.EXE - 10/02/92
        Displays the cache statistics of the CSC FastCache64 controller.

    FCMIRROR.EXE - 10/02/92
        Sets a second identical SCSI drive as a mirror drive. The mirror 
        drive will not be seen by the operating system.

    FCFORMAT.EXE - 10/02/92
        Used to low-level format SCSI hard drives, WORM drives and MO drives.
        WARNING - Do not low-level format SCSI Hard Disks unless absolutly 
            necessary.  These drives are low-level formatted at the
            factory.  
            If low-level formatting is performed, some hard drives such as
            the Maxtor 8760S will revert to factory settings which are NOT
            DOS or Windows compatable. If you are unsure of your drives
            default configuration, consult your OEM manual or call CSC 
            for assistance.

        See your CSC FastCache64 SCSI or CSC FlashCache64 SCSI manual for
        more information.

    FCSCAN.EXE - 10/02/92
        This utility simply scans the SCSI bus to determine what devices
        are attatched.

    2_88FLPY.TXT - 06/12/92
        2.88 Meg Floppy installation notes in ASCII format.  This file
        may be printed by using the DOS command:

        TYPE 2_88FLPY.TXT > PRN

        Note: Page formatting commands are embedded.
