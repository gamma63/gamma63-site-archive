================================================================================
                    INFORMATION REGARDING IBM PROPRINTERS
================================================================================

     You have selected one of the following printers:

             IBM Proprinter
             IBM Proprinter II
             IBM Proprinter XL

     Your printer has been installed; however, it has not yet been
     configured properly.  To properly configure your printer, use
     the Control  Panel.   For information on how to do this,  see
     "Configuring Your System" in Chapter 7, "Using Control Panel",
     of the Microsoft Windows User's Guide. Be sure to properly set
     up your communications port.



================================================================================
                              END OF READMEPR.TXT
================================================================================
