================================================================================
                    INFORMATION REGARDING EPSON LQ PRINTERS
================================================================================

     You have selected one of the following printers:

               Epson LQ800          Epson LQ850
               Epson LQ1000         Epson LQ1050
               Epson LQ1500         Epson LQ2500
               Epson SQ2500

     Your printer has been installed; however, it has not yet been
     configured properly.  To properly configure your printer, use
     the Control  Panel.   For information on how to do this,  see
     "Configuring Your System" in Chapter 7, "Using Control Panel",
     of the Microsoft Windows User's Guide. Be sure to properly set
     up your communications port.


================================================================================
                              END OF READMEEP.TXT
================================================================================
