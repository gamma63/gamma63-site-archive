================================================================================
                 INFORMATION REGARDING HEWLETT PACKARD PLOTTERS
================================================================================

You have selected one of the following plotters:

	HP 7470A           HP 7475A           HP 7550A
        HP 7580A           HP 7585A           HP 7580B
	HP 7585B           HP 7586B
	HP ColorPro        HP ColorPro with GEC
	HP DraftPro        HP DraftMaster I
        HP DraftMaster II

Your plotter has been installed; however, it has not yet been configured
properly. To properly configure your plotter, use the Control  Panel.
For information on how to do this,  see "Configuring Your System" in
Chapter 7, "Using Control Panel", of the Microsoft Windows User's Guide.
Be sure to properly set up your communications port.

================================================================================
                              END OF READMEPL.TXT
================================================================================
