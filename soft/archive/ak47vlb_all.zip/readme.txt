              The AK47VLB SCSI1 and SCSI2 Controller.
              ---------------------------------------

Specifications:
---------------
Internal Connector: IDC 50-pin
External Connector: SCSI2 DB25
SCSI Chip: Fujitsu MB86601A
Protocols Supported: SCSI1, and SCSI2
                     Disconnect/Reselect
                     Supports SCSI pass-through functionality
                     BUS device reset
                     Advanced SCSI Programming Interface (ASPI)
                     Single-threaded I/O

Maximum Burst: 10MB/sec
Bios Version 1.21

The AK47 controller card is compatible with the following
operating systems:
	MSDos
	Windows 31
	Windows 95a
	Windows NT 3.51 and 4.0
	OS2 Warp 3 and Warp 4
	Netware 3x and 4x
	
Termination:
------------
Termination on the card is controlled by three 10-pin terminator resisters
located near the internal connector. To disable termination on the card,
all resisters need to be removed. Keep these resisters in case termination
needs to be re-enabled at a future date. To enable termination, replace the 
resisters. Note pin one orientation on the resisters when installing.

Driver Installation:
--------------------

Drivers and instuctions are available on this disk in the following 
directories:

	MSDos/Windows31   a:\dos
	Windows 95a       a:\win95
        Windows NT 3x 4x  a:\winnt
	Netware 3x        a:\netware\3x
	Netware 4x        a:\netware\4x
	OS2 Warp 3x 4x    a:\os2
	Bios Utility      a:\flash-bios

Please use the README.TXT in each directory for additional information.

------------------------
Corporate Systems Center
1294 Hammerwood Ave
Sunnyvale CA 94089
408-734-3475
