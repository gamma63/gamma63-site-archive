CSC AK47 Controller Card Bios Update Utility.
---------------------------------------------

Usage:
------

Boot the system off a clean boot diskette loading no drivers.
Type "UPDATE.EXE" with any command options needed. The utility will load
and scan for the card. If the card is not shown, try again with the 
-a:XXXX option. Once the utility is loaded press return to update the bios.

When no command options are used, the utility defaults to the following
values:
	Bios Address C800.
	Parity enabled.
	Resetwait disabled.
	EnableBios enabled.

Command line options:
---------------------

The following options can be added to the command line:
	-a:XXXX		Where XXXX is the bios address of the AK47 card.
	-o:RESETWAIT    Enables SCSCI reset wait for older, slow-to-spin-up
			drives.
	-o:!RESETWAIT   Disables SCSI reset wait.
	-o:PARITY	Enables SCSI parity error checking.
	-o:!PARITY 	Disables SCSI parity.
	-o:ENABLEBIOS   Enables the SCSI Bios.
	-o:!ENABLEBIOS	Disables the SCSI Bios.

For example:
 UPDATE.EXE -a:C800 -o:RESETWAIT -o:!PARITY


------------------------
Corporate Systems Center
1294 Hammerwood Ave
Sunnyvale CA 94089
408-734-3475